
#ifndef REMOVE_INVALID_H
#define REMOVE_INVALID_H

#include "Company.h"

std::list<Company*> removeInvalid(std::list<Company*>& companies) {
	std::list<Company*>::iterator i = companies.begin();
	while (i != companies.end()){
		Company* entry = *i;
		if ((entry->getId()) < 0){	
			delete entry;
			i=companies.erase(i);//point to the next item after erasing
		}
		else{
			i++;
		}
	}
	return companies;
}

#endif // !REMOVE_INVALID_H

