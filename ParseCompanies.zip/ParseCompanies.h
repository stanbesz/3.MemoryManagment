#ifndef PARSE_COMPANIES_H
#define PARSE_COMPANIES_H
#include <set>
#include "Company.h"

Company* parseUniqueCompanies(const std::string &input,int &num, std::string(*parse)(const Company &c)) {
	std::stringstream insertinput(input);
	std::string companyLine;
	std::set<std::string> companiesKey;
	std::vector<Company> companies;
	while (std::getline(insertinput,companyLine)) {
		std::stringstream oneCompany(companyLine);
		int id = 0;
		std::string name;
		oneCompany >> id >> name;
		Company company(id, name);
		std::string uniqueParsing = parse(company);
		if (companiesKey.find(uniqueParsing) == companiesKey.end()) {
			companies.push_back(company);
			companiesKey.insert(uniqueParsing);
		}
		
	}
	num = companies.size();
	Company* companiesPoint = new Company[companies.size()];

	for (int i = 0; i < companies.size(); i++) {
		companiesPoint[i] = companies[i];
	}

	return companiesPoint;
}

#endif 
#pragma once
