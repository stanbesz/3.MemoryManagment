#ifndef SERIALIZE_H
#define SERAILIZE_H

#include "Company.h"

byte* serializeToMemory(std::string information, size_t &size) {
	std::stringstream inputLn(information);
	Company comp;

	std::vector<Company> companies;

	while (inputLn >> comp) {
		companies.push_back(comp);
	}

	std::vector<byte> byteInfo;

	byteInfo.push_back(companies.size());//num of companies

	for (int i = 0; i < companies.size(); i++) {
		byteInfo.push_back(companies[i].getId());
		for (char c : companies[i].getName()) {
			byteInfo.push_back((byte)c);
		}
		byteInfo.push_back('\0');
		byteInfo.push_back(companies[i].getEmployees().size());
		std::vector<std::pair<char, char> > employees = companies[i].getEmployees();
		for (int i = 0; i < employees.size(); i++) {
			byteInfo.push_back(employees[i].first);
			byteInfo.push_back(employees[i].second);
		}
	}
	size = byteInfo.size();
	byte* memory = new byte[byteInfo.size()];
	for (int i = 0; i < size; i++) {
		memory[i] = byteInfo[i];
	}

	return memory;
}

#endif
