#ifndef MIN_BY_H
#define MIN_BY_H



std::string minBy(std::vector<std::string> values,
    bool (*filter) (const std::string &word1, const std::string &word2)) {
    std::string result;

    result = values[0];
    for (int i = 0; i < values.size(); i++) { 
        std::string midRes = values[i];
        for (int j = 0; j < values.size(); j++) {
            if (filter(midRes, result)) {
                result=midRes;
            }
        }
       
    
    }

    return result;
}

#endif 
